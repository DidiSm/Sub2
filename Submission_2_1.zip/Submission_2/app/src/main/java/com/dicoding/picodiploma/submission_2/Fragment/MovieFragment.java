package com.dicoding.picodiploma.submission_2.Fragment;


import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dicoding.picodiploma.submission_2.Activity.DetailActivity;
import com.dicoding.picodiploma.submission_2.Adapter.RecycleAdapter;
import com.dicoding.picodiploma.submission_2.Data.Movie;
import com.dicoding.picodiploma.submission_2.R;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class MovieFragment extends Fragment {
    private  String[] judul, desc, tglMovie, crewMovie, crewDetailMovie;
    private TypedArray photo;
    private ArrayList<Movie> movies = new ArrayList<>();

    public MovieFragment() {
        // Required empty public constructor
    }

    public static Fragment newInstance(int i) {
        MovieFragment fragment = new MovieFragment();
        return fragment;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_movie, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.rv_movie);
        RecycleAdapter adapter = new RecycleAdapter(movies, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickCallback(new RecycleAdapter.OnItemClickCallback() {
            @Override
            public void onItemClicked(Movie movie) {
                showSelected(movie);
            }
        });

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        getData();
        addData();
    }

    private void addData() {
        movies = new ArrayList<>();
        for (int i=0; i<judul.length; i++){
            Movie movie = new Movie();
            movie.setJudul(judul[i]);
            movie.setTglMovie(tglMovie[i]);
            movie.setCrewMovie(crewMovie[i]);
            movie.setCrewDetailMovie(crewDetailMovie[i]);
            movie.setDesc(desc[i]);
            movie.setPhoto(photo.getResourceId(i,-1));

            movies.add(movie);
        }
    }

    private void getData() {
        judul = getResources().getStringArray(R.array.data_judul);
        tglMovie = getResources().getStringArray(R.array.data_tgl_movie);
        desc = getResources().getStringArray(R.array.data_desc);
        crewDetailMovie = getResources().getStringArray(R.array.detail_position);
        crewMovie = getResources().getStringArray(R.array.data_name_crew);
        photo = getResources().obtainTypedArray(R.array.data_photo);

    }

    private void showSelected(Movie movies) {
        Movie data = new Movie();
        data.setJudul(movies.getJudul());
        data.setTglMovie(movies.getTglMovie());
        data.setDesc(movies.getDesc());
        data.setCrewDetailMovie(movies.getCrewDetailMovie());
        data.setCrewMovie(movies.getCrewMovie());
        data.setPhoto(movies.getPhoto());

        Intent intent = new Intent(getContext(), DetailActivity.class);
        intent.putExtra(DetailActivity.EXTRA_MOVIE,data);
        startActivity(intent);
    }
}
