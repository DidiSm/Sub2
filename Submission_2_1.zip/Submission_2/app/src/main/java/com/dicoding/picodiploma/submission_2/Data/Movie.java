package com.dicoding.picodiploma.submission_2.Data;

import android.os.Parcel;
import android.os.Parcelable;

public class Movie implements Parcelable {

    private String judul, desc, tglMovie, crewMovie, crewDetailMovie;
    private int photo;


    public String getJudul() {
        return judul;
    }

    public void setJudul(String judul)   {
        this.judul = judul;
    }

    public String getDesc() {
        return desc;
    }

    public void setDesc(String desc) {
        this.desc = desc;
    }

    public String getTglMovie() {
        return tglMovie;
    }

    public void setTglMovie(String tglMovie) {
        this.tglMovie = tglMovie;
    }

    public String getCrewMovie() {
        return crewMovie;
    }

    public void setCrewMovie(String crewMovie) {
        this.crewMovie = crewMovie;
    }

    public String getCrewDetailMovie() {
        return crewDetailMovie;
    }

    public void setCrewDetailMovie(String crewDetailMovie) {
        this.crewDetailMovie = crewDetailMovie;
    }
    public int getPhoto() {
        return photo;
    }

    public void setPhoto(int photo) {
        this.photo = photo;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.judul);
        dest.writeString(this.desc);
        dest.writeString(this.tglMovie);
        dest.writeString(this.crewMovie);
        dest.writeString(this.crewDetailMovie);
        dest.writeInt(this.photo);
    }

    public Movie() {
    }

    private Movie(Parcel in) {
        this.judul = in.readString();
        this.desc = in.readString();
        this.tglMovie = in.readString();
        this.crewMovie = in.readString();
        this.crewDetailMovie = in.readString();
        this.photo = in.readInt();
    }

    public static final Parcelable.Creator<Movie> CREATOR = new Parcelable.Creator<Movie>() {
        @Override
        public Movie createFromParcel(Parcel source) {
            return new Movie(source);
        }

        @Override
        public Movie[] newArray(int size) {
            return new Movie[size];
        }
    };
}
