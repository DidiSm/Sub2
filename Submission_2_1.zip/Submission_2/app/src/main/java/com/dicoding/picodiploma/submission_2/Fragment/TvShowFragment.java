package com.dicoding.picodiploma.submission_2.Fragment;


import android.content.Intent;
import android.content.res.TypedArray;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.dicoding.picodiploma.submission_2.Activity.DetailActivity;
import com.dicoding.picodiploma.submission_2.Activity.DetailTvShow;
import com.dicoding.picodiploma.submission_2.Adapter.RecycleAdapter;
import com.dicoding.picodiploma.submission_2.Adapter.TvShowAdapter;
import com.dicoding.picodiploma.submission_2.Data.Movie;
import com.dicoding.picodiploma.submission_2.Data.Tv_Show;
import com.dicoding.picodiploma.submission_2.R;

import java.util.ArrayList;


/**
 * A simple {@link Fragment} subclass.
 */
public class TvShowFragment extends Fragment {
    private String[] tvJudul, tvRelease, tvDuration,tvDesc;
    private TypedArray tvPhoto;
    private ArrayList<Tv_Show> tv_shows = new ArrayList<>();

    public TvShowFragment() {
         //Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_tv_show, container, false);

        RecyclerView recyclerView = view.findViewById(R.id.rv_tv_show);
        TvShowAdapter adapter = new TvShowAdapter(tv_shows, getContext());
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);

        adapter.setOnItemClickCallback(new TvShowAdapter.onItemClickCallBack(){
            @Override
            public void onItemClicked(Tv_Show tv_show){
                showSelected(tv_show);
            }
        });

        return view;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState){
        super.onCreate(savedInstanceState);

        getData();
        addData();
    }

    private void addData() {
        tv_shows = new ArrayList<>();
        for (int i=0; i<tvJudul.length; i++){
            Tv_Show tv_show= new Tv_Show();
            tv_show.setTvJudul(tvJudul[i]);
            tv_show.setTvRelease(tvRelease[i]);
            tv_show.setTvDuration(tvDuration[i]);
            tv_show.setTvDesc(tvDesc[i]);
            tv_show.setPhoto(tvPhoto.getResourceId(i,-1));

            tv_shows.add(tv_show);
        }
    }

    private void getData() {
        tvJudul = getResources().getStringArray(R.array.tv_show_judul);
        tvRelease = getResources().getStringArray(R.array.tv_show_release);
        tvDuration = getResources().getStringArray(R.array.tv_show_duration);
        tvDesc = getResources().getStringArray(R.array.tv_show_desc);
        tvPhoto = getResources().obtainTypedArray(R.array.tv_show_photo);
    }

    private void showSelected(Tv_Show tv_show) {
        Tv_Show data = new Tv_Show();
        data.setTvJudul(tv_show.getTvJudul());
        data.setTvRelease(tv_show.getTvRelease());
        data.setTvDuration(tv_show.getTvDuration());
        data.setTvDesc(tv_show.getTvDesc());
        data.setPhoto(tv_show.getPhoto());

        Intent intent = new Intent(getContext(), DetailTvShow.class);
        intent.putExtra(DetailTvShow.EXTRA_TV,data);
        startActivity(intent);
    }
}
