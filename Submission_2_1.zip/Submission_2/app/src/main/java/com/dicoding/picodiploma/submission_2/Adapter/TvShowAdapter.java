package com.dicoding.picodiploma.submission_2.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.dicoding.picodiploma.submission_2.Activity.DetailTvShow;
import com.dicoding.picodiploma.submission_2.Data.Movie;
import com.dicoding.picodiploma.submission_2.Data.Tv_Show;
import com.dicoding.picodiploma.submission_2.R;

import java.util.ArrayList;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.TvShowViewHolder> {
    private final Context context;
    private ArrayList<Tv_Show> listTvShow;
    private OnItemClickCallback onItemClickCallback;

    public void setTv_shows(ArrayList<Tv_Show> tv_shows) {
        this.listTvShow = tv_shows;
    }

    public void setOnItemClickCallback(TvShowAdapter.OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public TvShowAdapter(ArrayList<Tv_Show> list,Context context) {
        this.listTvShow = list;
        this.context = context;
    }

    @NonNull
    @Override
    public TvShowViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view= LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_tv_show, viewGroup, false);
        return new TvShowViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final TvShowViewHolder holder, int position) {
        final Tv_Show tv_show = listTvShow.get(position);
        Glide.with(holder.tPhoto)
                .load(tv_show.getPhoto())
                .apply(new RequestOptions().override(55,55))
                .into(holder.tPhoto);

        holder.tPhoto.setImageResource(listTvShow.get(position).getPhoto());
        holder.tJudul.setText(listTvShow.get(position).getTvJudul());
        holder.tDesc.setText(listTvShow.get(position).getTvDesc());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickCallback.onItemClicked(listTvShow.get(holder.getAdapterPosition()));

                Tv_Show tv_show1 = new Tv_Show();
                tv_show1.setTvJudul(tv_show.getTvJudul());
                tv_show1.setTvRelease(tv_show.getTvRelease());
                tv_show1.setTvDuration(tv_show.getTvDuration());
                tv_show1.setTvDesc(tv_show.getTvDesc());
                tv_show1.setPhoto(tv_show.getPhoto());
            }
        });

    }

    @Override
    public int getItemCount() {
        return listTvShow.size();
    }

    public class TvShowViewHolder extends RecyclerView.ViewHolder {
        TextView tJudul, tDesc;
        ImageView tPhoto;

        public TvShowViewHolder(@NonNull View itemView) {
            super(itemView);
            tPhoto = itemView.findViewById(R.id.tvshow_photo);
            tJudul = itemView.findViewById(R.id.tvshow_judul);
            tDesc = itemView.findViewById(R.id.tvshow_desc);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Tv_Show tv_show);
    }

    public static class onItemClickCallBack implements OnItemClickCallback {
        @Override
        public void onItemClicked(Tv_Show tv_show) {
        }
    }
}
